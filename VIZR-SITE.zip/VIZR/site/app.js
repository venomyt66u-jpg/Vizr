/* ============================================================================
   VIZR — page behaviour. Vanilla, no dependencies.
   ========================================================================= */

/* ---- mint countdown ------------------------------------------------------
   Target is 16:00 UTC today. If that moment has already passed on the
   visitor's clock we roll to the next day rather than showing a dead zero —
   a countdown stuck at 00:00:00 looks broken, not live. */
function mintTarget() {
  const now = new Date();
  const t = new Date(Date.UTC(
    now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 16, 0, 0));
  if (t.getTime() <= now.getTime()) t.setUTCDate(t.getUTCDate() + 1);
  return t;
}

const TARGET = mintTarget();
const AL = new Date(TARGET.getTime() - 60 * 60 * 1000);   // allowlist, 1h prior

function pad(n, w) { return String(n).padStart(w || 2, "0"); }

function tick() {
  const now = Date.now();
  let ms = TARGET.getTime() - now;
  const live = ms <= 0;
  if (ms < 0) ms = 0;

  const d = Math.floor(ms / 864e5);
  const h = Math.floor(ms / 36e5) % 24;
  const m = Math.floor(ms / 6e4) % 60;
  const s = Math.floor(ms / 1e3) % 60;

  document.getElementById("d").textContent = pad(d);
  document.getElementById("h").textContent = pad(h);
  document.getElementById("m").textContent = pad(m);
  document.getElementById("s").textContent = pad(s);

  const btn = document.getElementById("mintbtn");
  const note = document.getElementById("mintnote");
  const nav = document.getElementById("navstate");
  const day = document.getElementById("mintday");

  const alOpen = now >= AL.getTime() && !live;

  if (live) {
    btn.disabled = false;
    btn.textContent = "Mint now";
    note.textContent = "Public mint is open. 0.0088 ETH · max 5 per wallet.";
    nav.textContent = "MINT LIVE";
    day.textContent = "LIVE";
  } else if (alOpen) {
    btn.disabled = false;
    btn.textContent = "Mint — allowlist";
    note.textContent = "Allowlist window. Public opens at 16:00 UTC.";
    nav.textContent = "ALLOWLIST OPEN";
    day.textContent = "ALLOWLIST";
  } else {
    btn.disabled = true;
    btn.textContent = `Mint opens in ${pad(h)}:${pad(m)}:${pad(s)}`;
    nav.textContent = d > 0 ? "MINT SOON · 16:00 UTC" : "MINT TODAY · 16:00 UTC";
    day.textContent = d > 0 ? "TOMORROW" : "TODAY";
  }
}

/* ---- machine grid --------------------------------------------------------- */
const TIER_CLASS = {
  Common: "t-common", Uncommon: "t-uncommon", Rare: "t-rare",
  Epic: "t-epic", Legendary: "t-legendary",
};

function buildMachines(list) {
  const g = document.getElementById("machgrid");
  g.innerHTML = list.map(m => `
    <figure class="mach">
      <img src="img/${m.slug}.png" alt="${m.name}" loading="lazy" width="256" height="256">
      <figcaption class="meta">
        <span class="nm">${m.name}</span>
        <span class="tr ${TIER_CLASS[m.tier]}">${m.tier.toUpperCase()}</span>
      </figcaption>
    </figure>`).join("");
}

/* ---- tier bars ------------------------------------------------------------ */
const TIERS = [
  { nm: "Common",    n: 1400, c: "#626875", cls: "t-common",
    ms: "Desktop Rig · Tower Rig · USB Miner · Laptop Rig · Shelf Miner · Open Frame" },
  { nm: "Uncommon",  n: 933,  c: "#62c6f0", cls: "t-uncommon",
    ms: "ASIC Box · Server Blade · Cooling Tower · Wall Cabinet · Bill Printer" },
  { nm: "Rare",      n: 633,  c: "#a98cf5", cls: "t-rare",
    ms: "Immersion Tank · Solar Rig · Coin Press · Vault Printer" },
  { nm: "Epic",      n: 300,  c: "#fcba3e", cls: "t-epic",
    ms: "Data Furnace · Quantum Cabinet · Steam Rig" },
  { nm: "Legendary", n: 67,   c: "#edc351", cls: "t-legendary",
    ms: "Gold Foundry (20) · The Mint (47)" },
];

function buildTiers() {
  const total = 3333;
  document.getElementById("tiergrid").innerHTML = TIERS.map(t => {
    const pc = (t.n / total * 100);
    return `<div class="tier" style="border-left-color:${t.c}">
      <div class="nm ${t.cls}">${t.nm}</div>
      <div class="bar"><i style="width:${pc.toFixed(1)}%;background:${t.c}"></i></div>
      <div class="ct">${t.n.toLocaleString()}</div>
      <div class="pc">${pc.toFixed(1)}%</div>
      <div class="list">${t.ms}</div>
    </div>`;
  }).join("");
}

/* ---- boot ----------------------------------------------------------------- */
fetch("machines.json")
  .then(r => r.json())
  .then(buildMachines)
  .catch(() => {
    document.getElementById("machgrid").innerHTML =
      '<p style="padding:30px;color:#626875">Machine grid needs a local server ' +
      '(<code>python3 -m http.server</code>) — browsers block fetch on file://</p>';
  });

buildTiers();
paintType(document);
tick();
setInterval(tick, 1000);

/* Mint button is a placeholder until the contract is live; say so plainly
   rather than opening a dead wallet modal. */
document.getElementById("mintbtn").addEventListener("click", e => {
  if (e.currentTarget.disabled) return;
  const n = document.getElementById("mintnote");
  n.textContent = "Wallet connection ships with the contract deploy.";
  n.style.color = "#fcba3e";
});
