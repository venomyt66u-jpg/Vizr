# VIZR — mint site

Static. Three files, no build step, no dependencies, no package manager.

```bash
cd site && python3 -m http.server 8000
```
A server is needed only because `machines.json` is loaded with `fetch`, which
browsers block on `file://`.

## What's deliberate here

**The typeface is drawn, not imported.** `vizrface.js` holds a 7×9 bitmap for
every glyph and renders headlines as SVG `<rect>`s at runtime. No webfont, no
`@import`, no Google Fonts. A downloaded font gets hinted and antialiased by the
browser and will never sit exactly on the pixel grid the artwork uses; drawing
the letterforms means they line up at any size, on any screen. The face is
intentionally heavy — 2px stems on a 7-wide body, flat terminals, no diagonal
thinner than the stem — so it reads as stamped metal rather than retro-gaming.
Adjacent lit pixels in a row are merged into single rects, so a headline is
~200 nodes instead of ~1500.

**No framework and no utility classes.** `style.css` is written by hand. The
palette is lifted directly out of `rigs/core.py`, so the site and the tokens
share the same ramps. Everything is a multiple of 4px, borders are hard 2px,
shadows are offset solid blocks rather than blur, and there is not one
`border-radius` in the file.

**Body text uses the system monospace stack** — `ui-monospace, SF Mono, Menlo,
Consolas`. Nothing is fetched over the network.

**The countdown targets 16:00 UTC.** If that has already passed on the visitor's
clock it rolls to the next day rather than sitting at zero, because a dead
`00:00:00` reads as broken rather than live. The allowlist state flips on
automatically one hour before. Everything is computed from the device clock.

## Sections
Hero + mint panel · stat strip · 20 machines · 5 rarity tiers · 8 trait layers ·
on-chain explanation with `tokenURI` · FAQ · footer.

## Files
| | |
|---|---|
| `index.html` | markup |
| `style.css` | all styling |
| `vizrface.js` | the drawn typeface + renderer |
| `app.js` | countdown, machine grid, tier bars |
| `machines.json` | the 20 builds with tier + token id |
| `img/` | one still per machine, plus the animated hero and mark |

## Before launch
`app.js` — the mint button is a placeholder and says so; wire it to the contract
on deploy. Prices, wallet cap and royalty live in `index.html` under `.mint-rows`.
