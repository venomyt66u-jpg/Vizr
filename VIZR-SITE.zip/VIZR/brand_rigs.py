"""RIGS — Twitter banner and PFP.

Both use the collection's own renderer, so the brand art is made of literally
the same machines as the tokens. The only thing added here is a wide canvas and
a hand-composed scene: a mining farm in perspective rather than one rig
centred in a room.

Twitter crops a header hard on mobile — roughly the middle 60% survives — so
nothing that carries the identity is allowed near the left or right edge.
"""
import numpy as np
from PIL import Image

import rigs.core as RC
from rigs.core import (Canvas, blank, rect, ellipse, disc, line, shift, dilate,
                       outline_of, bayer, panel, shade, ink, glow, RAMPS, LED)
from rigs.render import fan_blades, MONEY, MONEY_D, COIN

BW, BH = 256, 86           # banner native; x6 -> 1536x516
PW = 128                   # pfp native; x8 -> 1024


# ------------------------------------------------------------- helpers -----

def R(x0, y0, x1, y1, w, h):
    return rect(x0, y0, x1, y1, w, h)


def sized(fn, w, h):
    """Most core helpers default to a 128 grid; bind them to this canvas."""
    return lambda *a, **k: fn(*a, w=w, h=h, **k)


def rack(c, x, y, rw, rh, key, led, w, h, shelves=3, dim=1.0):
    """One rack unit. `dim` fakes distance — a rack further back is darker and
    lower contrast, which is the only depth cue available without perspective
    projection."""
    _r = sized(rect, w, h)
    _d = sized(disc, w, h)
    body = _r(x, y, x + rw, y + rh)
    panel(c, body, key)
    fans, leds = [], []
    step = rh // shelves
    for i in range(shelves):
        sy = y + i * step + 2
        sh_ = _r(x + 2, sy, x + rw - 2, sy + step - 3)
        panel(c, sh_, 'carbon', (1, 3, 7, 12))
        fr = max(2, min(step // 3, rw // 6))
        for fx in (x + 5 + fr, x + rw - 6 - fr):
            well = _d(fx, sy + (step - 3) // 2, fr)
            shade(c, well, 'gunmetal', (1, 2, 5, 9))
            fans.append((fx, sy + (step - 3) // 2, fr - 1))
        for k in range(3):
            leds.append((x + rw // 2 - 3 + k * 3, sy + step - 6))
        for gx in range(x + rw // 2 - 6, x + rw // 2 + 7, 3):
            c.blend(_r(gx, sy + 2, gx + 2, sy + step - 8), RAMPS['carbon'][0], .6)
    ink(c, body)
    if dim < 1.0:
        c.multiply(dilate(body, 1), dim)
    return fans, leds, body


def cables(c, rng, n, w, h, ytop, ybot):
    for _ in range(n):
        x0 = int(rng.integers(0, w // 3))
        x1 = int(rng.integers(2 * w // 3, w))
        y0 = int(rng.integers(ytop, ybot))
        sag = int(rng.integers(4, 14))
        m = blank(w, h)
        for x in range(x0, x1):
            t = (x - x0) / max(1, x1 - x0)
            yy = int(y0 + sag * np.sin(np.pi * t))
            if 0 <= yy < h:
                m[yy, x] = True
                m[min(h - 1, yy + 1), x] = True
        c.blend(m, RAMPS['rubber'][1])
        c.blend(shift(m, 0, -1) & ~m, RAMPS['rubber'][3], .45)


# -------------------------------------------------------------- banner -----

def banner_plate():
    """Room + racks + cables. Static across every frame."""
    c = Canvas(BW, BH)
    rng = np.random.default_rng(11)
    _r = sized(rect, BW, BH)
    pal = RAMPS['concrete']
    FLOOR = 74

    c.blend(_r(0, 0, BW, BH), pal[1])
    c.blend(_r(0, 0, BW, FLOOR), pal[2])
    for x in range(0, BW, 26):
        c.blend(_r(x, 0, x + 1, FLOOR), pal[1], .6)
    for y in range(0, FLOOR, 22):
        c.blend(_r(0, y, BW, y + 1), pal[1], .45)
    c.blend(_r(0, FLOOR, BW, BH), pal[0])
    c.blend(_r(0, FLOOR, BW, FLOOR + 2), pal[3], .45)
    for x in range(-30, BW, 30):
        c.blend(line(x, FLOOR, x - 18, BH, 1, BW, BH), pal[1], .45)

    fans, leds = [], []
    # back row: small, dim, receding. Sits high so the front row can't hide it.
    for i, x in enumerate(range(2, BW - 16, 38)):
        f, l, _ = rack(c, x, 14, 26, 30, 'gunmetal', 'Cyan', BW, BH, 2, dim=0.55)
        fans += [(a, b, r, 0.55) for a, b, r in f]
        leds += [(a, b, 0.55) for a, b in l]

    cables(c, rng, 3, BW, BH, 8, 20)

    # front row with a deliberate GAP at centre. Packed edge to edge the racks
    # fuse into one wall and there is nowhere for the eye to land.
    HERO_X0, HERO_X1 = BW // 2 - 26, BW // 2 + 26
    front_keys = ['steel', 'navy', 'teal', 'olive', 'gunmetal', 'rust', 'crimson']
    ki = 0
    for x in range(-8, BW, 46):
        if HERO_X0 - 34 < x < HERO_X1:
            continue
        k = front_keys[ki % len(front_keys)]; ki += 1
        f, l, _ = rack(c, x, 44, 34, 40, k, 'Green', BW, BH, 3, dim=1.0)
        fans += [(a, b, r, 1.0) for a, b, r in f]
        leds += [(a, b, 1.0) for a, b in l]

    cables(c, rng, 2, BW, BH, 36, 44)

    # the hero printer, drawn LAST so nothing overlaps it, dead centre where
    # Twitter's mobile crop is guaranteed to keep it
    px = BW // 2 - 18
    base = _r(px - 4, 78, px + 40, 84)
    panel(c, base, 'concrete', (1, 3, 7, 12))
    body = _r(px, 34, px + 36, 80)
    panel(c, body, 'gold')
    panel(c, _r(px + 4, 38, px + 32, 54), 'glass', (1, 2, 5, 9))
    for gy in (58, 64):
        panel(c, _r(px + 4, gy, px + 32, gy + 4), 'carbon', (0, 1, 3, 6))
    slot = _r(px + 9, 70, px + 27, 73)
    panel(c, slot, 'carbon', (0, 1, 3, 6))
    for sx in (px, px + 32):
        panel(c, _r(sx, 30, sx + 4, 80), 'brass', (0, 1, 3, 6))
    panel(c, _r(px - 3, 28, px + 39, 34), 'brass', (0, 1, 4, 8))
    ink(c, body | base)
    printer_slot = (px + 18, 70, 16)
    leds += [(px + 8 + k * 6, 76, 1.0) for k in range(4)]

    # vignette
    yy, xx = np.mgrid[0:BH, 0:BW]
    d = np.sqrt(((xx - BW / 2) / (BW * .58)) ** 2 + ((yy - BH / 2) / (BH * .78)) ** 2)
    fall = np.clip(1.0 - .62 * np.clip(d - .42, 0, None) ** 1.2, .34, 1.0)
    for ch in range(3):
        c.buf[:, :, ch] *= fall

    return c.buf, fans, leds, printer_slot


def banner_frame(plate, fans, leds, slot, phase):
    c = Canvas(BW, BH)
    np.copyto(c.buf, plate)
    _d = sized(disc, BW, BH)
    _r = sized(rect, BW, BH)

    for i, (cx, cy, r, dim) in enumerate(fans):
        m = blank(BW, BH)
        for b in range(4):
            a = phase * 2.4 + b * np.pi / 2 + i * 0.4
            for t in np.linspace(0.3, 1.0, 6):
                m |= _d(cx + np.cos(a + t * .8) * r * t,
                        cy + np.sin(a + t * .8) * r * t, max(1, int(r * .3)))
        m &= _d(cx, cy, r)
        c.blend(m, RAMPS['steel'][2], dim)
        c.blend(m & ~shift(m, 0, 1), RAMPS['steel'][4], .45 * dim)

    for i, (x, y, dim) in enumerate(leds):
        on = np.sin(phase * 1.7 + i * 2.1) > -0.3
        col = LED['Cyan'] if dim < 1 else LED['Green']
        d = _d(x, y, 0 if dim < 1 else 1)
        c.blend(d, col if on else tuple(int(v * .25) for v in col), dim)
        if on and dim >= 1:
            glow(c, d, col, 3, .7)

    sx, sy, sw = slot
    for i in range(4):
        t = ((phase / (2 * np.pi)) * 4 + i) % 4
        oy = int(sy + 4 + t * 6)
        if oy > BH - 3:
            continue
        fade = 1.0 - t / 4.6
        b = _r(sx - sw // 2 + int(np.sin(t * 2)), oy,
               sx + sw // 2 + int(np.sin(t * 2)), oy + 4)
        c.blend(b, MONEY, fade)
        c.blend(b & ~shift(b, 0, 1), (170, 232, 176, 255), fade * .8)
        c.blend(b & ~shift(b, 0, -1), MONEY_D + (255,), fade * .9)
    return c


# ----------------------------------------------------------------- pfp -----

def pfp_plate(chassis='navy', led='Green', bgkey='concrete'):
    """One rig, cropped close. A PFP has to survive at 40px, so this is a
    single machine filling the frame — not a farm, not a room."""
    c = Canvas(PW, PW)
    _r = sized(rect, PW, PW)
    _d = sized(disc, PW, PW)
    pal = RAMPS[bgkey]

    c.blend(_r(0, 0, PW, PW), pal[2])
    for x in range(0, PW, 24):
        c.blend(_r(x, 0, x + 1, PW), pal[1], .5)
    for y in range(0, PW, 24):
        c.blend(_r(0, y, PW, y + 1), pal[1], .4)

    body = _r(14, 6, 114, 104)
    panel(c, body, chassis)
    face = _r(19, 11, 109, 99)
    panel(c, face, 'carbon', (2, 5, 10, 17))

    fans = []
    for cx, cy in ((44, 38), (84, 38)):
        well = _d(cx, cy, 19)
        shade(c, well, 'gunmetal', (1, 3, 7, 12))
        c.blend(_d(cx, cy, 18) & ~_d(cx, cy, 16), RAMPS['gunmetal'][4], .45)
        ink(c, well)
        fans.append((cx, cy, 16))

    scr = _r(28, 64, 100, 84)
    panel(c, scr, 'glass', (2, 4, 9, 15))
    ink(c, scr)

    slot = _r(34, 88, 94, 93)
    panel(c, slot, 'carbon', (0, 1, 3, 6))

    for sx in (14, 108):
        panel(c, _r(sx, 2, sx + 6, 108), 'steel', (0, 1, 3, 6))
    ink(c, body)

    leds = [(26, 92), (102, 92), (26, 56), (102, 56)]

    yy, xx = np.mgrid[0:PW, 0:PW]
    d = np.sqrt(((xx - 64) / 74.0) ** 2 + ((yy - 64) / 74.0) ** 2)
    fall = np.clip(1.0 - .5 * np.clip(d - .55, 0, None) ** 1.2, .45, 1.0)
    for ch in range(3):
        c.buf[:, :, ch] *= fall

    return c.buf, fans, leds, scr, (64, 88, 26)


def pfp_frame(plate, fans, leds, scr, slot, phase, ledname='Green'):
    c = Canvas(PW, PW)
    np.copyto(c.buf, plate)
    _d = sized(disc, PW, PW)
    _r = sized(rect, PW, PW)
    col = LED[ledname]

    for cx, cy, r in fans:
        m = blank(PW, PW)
        for b in range(5):
            a = phase * 2.2 + b * 2 * np.pi / 5
            for t in np.linspace(0.25, 1.0, 10):
                m |= _d(cx + np.cos(a + t * .8) * r * t,
                        cy + np.sin(a + t * .8) * r * t, max(1, int(r * .18)))
        m &= _d(cx, cy, r)
        c.blend(m, RAMPS['steel'][2])
        c.blend(m & ~shift(m, 0, 1), RAMPS['steel'][4], .5)
        hub = _d(cx, cy, r // 3)
        c.blend(hub, RAMPS['gunmetal'][2])
        c.blend(hub & ~shift(hub, 1, 1), RAMPS['gunmetal'][4], .6)

    c.blend(scr, tuple(int(v * .28) for v in col), .5)
    rows = np.where(scr.any(axis=1))[0]
    for i, y in enumerate(rows[1::4]):
        w = 8 + int(34 * abs(np.sin(phase * .9 + i * 1.4)))
        c.blend(_r(31, y, 31 + w, y + 2) & scr, col, .9)
    sweep = int(rows[0] + (phase / (2 * np.pi)) * (rows[-1] - rows[0]))
    c.blend(_r(0, sweep, PW, sweep + 2) & scr, col, .22)

    for i, (x, y) in enumerate(leds):
        on = np.sin(phase * 1.6 + i * 2.0) > -0.35
        d = _d(x, y, 1)
        c.blend(d, col if on else tuple(int(v * .28) for v in col))
        if on:
            glow(c, d, col, 4, .8)

    sx, sy, sw = slot
    for i in range(4):
        t = ((phase / (2 * np.pi)) * 4 + i) % 4
        oy = int(sy + 5 + t * 7)
        if oy > PW - 4:
            continue
        fade = 1.0 - t / 4.6
        b = _r(sx - sw // 2 + int(2 * np.sin(t * 2)), oy,
               sx + sw // 2 + int(2 * np.sin(t * 2)), oy + 5)
        c.blend(b, MONEY, fade)
        c.blend(b & ~shift(b, 0, 1), (170, 232, 176, 255), fade * .8)
        c.blend(b & ~shift(b, 0, -1), MONEY_D + (255,), fade * .9)
        c.blend(_d(sx + int(2 * np.sin(t * 2)), oy + 2, 1), MONEY_D + (255,), fade)
    return c


if __name__ == '__main__':
    import os
    os.makedirs('brand_rigs', exist_ok=True)

    plate, fans, leds, slot = banner_plate()
    frames = [banner_frame(plate, fans, leds, slot, 2 * np.pi * f / 10).to_image(6)
              for f in range(10)]
    frames[0].convert('RGB').save('brand_rigs/banner.png')
    frames[0].convert('RGB').resize((1500, 500), Image.NEAREST).save(
        'brand_rigs/banner-1500x500.png')
    rgb = [f.convert('RGB') for f in frames]
    pal = rgb[0].quantize(colors=200, method=Image.MEDIANCUT)
    q = [f.quantize(palette=pal, dither=Image.NONE) for f in rgb]
    q[0].save('brand_rigs/banner-animated.gif', save_all=True,
              append_images=q[1:], duration=110, loop=0, optimize=True,
              disposal=2)

    pp, pf, pl, ps, pslot = pfp_plate()
    pframes = [pfp_frame(pp, pf, pl, ps, pslot, 2 * np.pi * f / 10).to_image(8)
               for f in range(10)]
    pframes[0].convert('RGB').save('brand_rigs/pfp.png')
    pframes[0].convert('RGB').resize((400, 400), Image.NEAREST).save(
        'brand_rigs/pfp-400.png')
    prgb = [f.convert('RGB') for f in pframes]
    ppal = prgb[0].quantize(colors=200, method=Image.MEDIANCUT)
    pq = [f.quantize(palette=ppal, dither=Image.NONE) for f in prgb]
    pq[0].save('brand_rigs/pfp-animated.gif', save_all=True,
               append_images=pq[1:], duration=110, loop=0, optimize=True,
               disposal=2)
    print('banner', frames[0].size, 'pfp', pframes[0].size)
