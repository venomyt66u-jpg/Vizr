"""Lighter distribution build: 6 frames, 96 colours, 512px.
Visually near-identical to the 8-frame 768px master, ~58% smaller."""
import os, sys
from PIL import Image
SRC, DST, NF, COLS, PX = 'rigs_out/images', 'rigs_light/images', 6, 96, 512
os.makedirs(DST, exist_ok=True)
n = int(sys.argv[1]) if len(sys.argv) > 1 else 3333
for i in range(1, n + 1):
    im = Image.open(os.path.join(SRC, f'{i}.gif'))
    fr = []
    for k in range(im.n_frames):
        im.seek(k); fr.append(im.convert('RGB'))
    sel = [fr[int(j * len(fr) / NF)].resize((PX, PX), Image.NEAREST)
           for j in range(NF)]
    pal = sel[0].quantize(colors=COLS, method=Image.MEDIANCUT)
    qs = [f.quantize(palette=pal, dither=Image.NONE) for f in sel]
    qs[0].save(os.path.join(DST, f'{i}.gif'), save_all=True,
               append_images=qs[1:], duration=146, loop=0, optimize=True,
               disposal=2)
    if i % 250 == 0:
        print(f'  {i}/{n}', flush=True)
print('done')
