"""Render a rig, static plate + animated overlay.

The plate (room, machine, cables, wear) is identical in every frame, so it is
built once and memcpy'd; only fans, LEDs, ejected bills, smoke and glow are
repainted. That is what keeps an 8-frame animated token under a second.
"""
import numpy as np
from .core import (NATIVE, SCALE, Canvas, blank, rect, ellipse, disc, line,
                   shift, dilate, erode, outline_of, bayer, panel, shade, ink,
                   glow, RAMPS, LED, BG)
from .machines import MACHINES, FLOOR

MONEY = (108, 190, 122)
MONEY_D = (52, 116, 76)
COIN = (240, 196, 72)


# ---------------------------------------------------------------- room -----

def draw_room(c, bg_key, rng):
    key = BG[bg_key][0]
    pal = RAMPS[key]
    c.blend(rect(0, 0, NATIVE, NATIVE), pal[1])
    c.blend(rect(0, 0, NATIVE, FLOOR), pal[2])
    # wall panelling
    for x in range(0, NATIVE, 22):
        c.blend(rect(x, 0, x + 1, FLOOR), pal[1], .7)
    for y in range(0, FLOOR, 26):
        c.blend(rect(0, y, NATIVE, y + 1), pal[1], .55)
    # floor
    c.blend(rect(0, FLOOR, NATIVE, NATIVE), pal[0])
    c.blend(rect(0, FLOOR, NATIVE, FLOOR + 2), pal[3], .5)
    for x in range(-20, NATIVE, 26):
        c.blend(line(x, FLOOR, x - 14, NATIVE, 1), pal[1], .5)
    # grime
    for _ in range(40):
        x, y = int(rng.integers(0, NATIVE)), int(rng.integers(0, NATIVE))
        c.blend(disc(x, y, 0), pal[0] if rng.random() < .5 else pal[3],
                rng.random() * .18)
    # vignette
    yy, xx = np.mgrid[0:NATIVE, 0:NATIVE]
    d = np.sqrt(((xx - 64) / 78.0) ** 2 + ((yy - 60) / 78.0) ** 2)
    fall = np.clip(1.0 - 0.55 * np.clip(d - .5, 0, None) ** 1.2, .40, 1.0)
    for ch in range(3):
        c.buf[:, :, ch] *= fall


def draw_cables(c, rng, n):
    """Cables sell 'this is a real rig' more than any amount of chassis
    detail. They hang in catenaries and disappear off frame."""
    for _ in range(n):
        x0 = int(rng.integers(4, 40))
        x1 = int(rng.integers(88, 124))
        y0 = int(rng.integers(20, 60))
        sag = int(rng.integers(6, 20))
        m = blank()
        for x in range(x0, x1):
            t = (x - x0) / max(1, (x1 - x0))
            y = int(y0 + sag * np.sin(np.pi * t))
            if 0 <= y < NATIVE:
                m[y, x] = True
                m[min(NATIVE - 1, y + 1), x] = True
        c.blend(m, RAMPS['rubber'][1])
        c.blend(shift(m, 0, -1) & ~m, RAMPS['rubber'][3], .5)


# ------------------------------------------------------------- animation ---

def fan_blades(cx, cy, r, phase, blades=5):
    m = blank()
    for b in range(blades):
        a = phase + b * 2 * np.pi / blades
        for t in np.linspace(0.25, 1.0, 10):
            x = cx + np.cos(a + t * 0.8) * r * t
            y = cy + np.sin(a + t * 0.8) * r * t
            m |= disc(x, y, max(1, int(r * 0.18)))
    m &= disc(cx, cy, r)
    return m


def draw_frame(c, parts, attrs, phase, rng):
    led = LED[attrs['LED']]

    for (cx, cy, r) in parts.get('fans', []):
        bl = fan_blades(cx, cy, r, phase * 2.2)
        c.blend(bl, RAMPS['steel'][2])
        c.blend(bl & ~shift(bl, 0, 1), RAMPS['steel'][4], .5)
        hub = disc(cx, cy, max(1, r // 3))
        c.blend(hub, RAMPS['gunmetal'][2])
        c.blend(hub & ~shift(hub, 1, 1), RAMPS['gunmetal'][4], .6)

    for i, (x, y) in enumerate(parts.get('leds', [])):
        on = (np.sin(phase * 1.6 + i * 1.9) > -0.35)
        d = disc(x, y, 1)
        c.blend(d, led if on else tuple(int(v * .28) for v in led))
        if on:
            glow(c, d, led, 4, .8)

    scr = parts.get('screen')
    if scr is not None and scr.any():
        c.blend(scr, tuple(int(v * .30) for v in led), .55)
        rows = np.where(scr.any(axis=1))[0]
        for i, y in enumerate(rows[1::3]):
            w = 6 + int(10 * abs(np.sin(phase * .9 + i * 1.3)))
            xs = np.where(scr[y])[0]
            if len(xs):
                bar = rect(xs[0] + 2, y, min(xs[-1] - 1, xs[0] + 2 + w), y + 1) & scr
                c.blend(bar, led, .85)
        sweep = int((phase / (2 * np.pi)) * (rows[-1] - rows[0])) + rows[0]
        c.blend(rect(0, sweep, NATIVE, sweep + 2) & scr, led, .25)

    core = parts.get('core')
    if core is not None:
        pulse = .5 + .5 * np.sin(phase * 2)
        c.add(core, led, .6 + .4 * pulse)
        glow(c, core, led, 10, .7 * (0.5 + pulse))

    fire = parts.get('fire')
    if fire is not None:
        for i in range(14):
            x = int(rng.integers(0, NATIVE)); y = int(rng.integers(0, NATIVE))
            if not fire[y, x]:
                continue
        ys = np.where(fire.any(axis=1))[0]
        xs = np.where(fire.any(axis=0))[0]
        for i in range(16):
            fx = int(xs[0] + (i * 7 + phase * 3) % max(1, (xs[-1] - xs[0])))
            fy = int(ys[-1] - abs(np.sin(phase + i)) * (ys[-1] - ys[0]) * .8)
            d = disc(fx, fy, 1 + (i % 2))
            c.add(d & fire, (250, 150, 40), .55)
        c.add(fire, (180, 70, 20), .25 + .1 * np.sin(phase * 2))
        glow(c, fire, (240, 140, 40), 6, .5)

    bub = parts.get('bubbles')
    if bub is not None:
        for i in range(18):
            bx = int(30 + (i * 13 + i * i) % 66)
            by = int(102 - ((phase * 6 + i * 9) % 46))
            d = disc(bx, by, 1)
            c.blend(d & bub, RAMPS['glass'][4], .55)

    ram = parts.get('ram')
    if ram is not None:
        drop = int(6 * max(0, np.sin(phase)))
        m = shift(ram, 0, drop)
        panel(c, m, 'brass', (1, 2, 5, 9))
        ink(c, m)

    wh = parts.get('wheel')
    if wh is not None:
        cx, cy, r = wh
        for a in range(6):
            ang = phase * 1.4 + a * np.pi / 3
            c.blend(line(cx + np.cos(ang) * 3, cy + np.sin(ang) * 3,
                         cx + np.cos(ang) * r, cy + np.sin(ang) * r, 2)
                    & disc(cx, cy, r + 1), RAMPS['brass'][3])

    g = parts.get('gauge')
    if g is not None:
        gx, gy, gr = g
        ang = -2.2 + 1.6 * (0.5 + 0.5 * np.sin(phase * 1.3))
        c.blend(line(gx, gy, gx + np.cos(ang) * gr, gy + np.sin(ang) * gr, 1),
                (220, 60, 60, 255))

    sm = parts.get('smoke')
    if sm is not None:
        sx, sy = sm
        for i in range(9):
            t = i + phase * 1.4
            px = int(sx + 3 * np.sin(t * .5) + i * .4)
            py = int(sy - i * 2.4 - phase)
            if 0 <= px < NATIVE and 0 <= py < NATIVE:
                c.blend(disc(px, py, 1 if i < 5 else 2), (188, 186, 190, 255),
                        max(0, .34 - i * .032))

    slot = parts.get('slot')
    out = attrs.get('Output', 'None')
    if slot is not None and out != 'None':
        sx, sy, sw = slot
        for i in range(4):
            t = ((phase / (2 * np.pi)) * 4 + i) % 4
            oy = int(sy + 4 + t * 9)
            if oy > NATIVE - 2:
                continue
            fade = 1.0 - t / 4.6
            if out == 'Bills':
                b = rect(sx - sw // 2 + int(2 * np.sin(t * 2)), oy,
                         sx + sw // 2 + int(2 * np.sin(t * 2)), oy + 5)
                c.blend(b, MONEY, fade)
                c.blend(b & ~shift(b, 0, 1), (170, 232, 176, 255), fade * .8)
                c.blend(b & ~shift(b, 0, -1), MONEY_D + (255,), fade * .9)
                c.blend(disc(sx + int(2 * np.sin(t * 2)), oy + 2, 1),
                        MONEY_D + (255,), fade)
            elif out == 'Coins':
                for k in (-1, 1):
                    d = ellipse(sx + k * 5 + int(3 * np.sin(t * 3)), oy, 3, 2)
                    c.blend(d, COIN + (255,), fade)
                    c.blend(d & ~shift(d, 0, 1), (252, 232, 150, 255), fade)
            elif out == 'Cards':
                b = rect(sx - sw // 2, oy, sx + sw // 2, oy + 4)
                c.blend(b, RAMPS['ivory'][3], fade)
                c.blend(rect(sx - sw // 2, oy, sx - sw // 2 + 4, oy + 4),
                        RAMPS['copper'][3], fade)


# ---------------------------------------------------------------- token ----

def render_plate(attrs, seed):
    rng = np.random.default_rng(seed)
    c = Canvas()
    draw_room(c, attrs['Background'], rng)
    parts = MACHINES[attrs['Machine']](c, attrs['Chassis'])
    draw_cables(c, rng, {'None': 0, 'Few': 2, 'Messy': 5}[attrs['Cables']])
    if attrs['Wear'] != 'Clean':
        n = {'Scuffed': 14, 'Rusted': 30}[attrs['Wear']]
        key = 'rust' if attrs['Wear'] == 'Rusted' else 'carbon'
        for _ in range(n):
            x, y = int(rng.integers(20, 108)), int(rng.integers(24, 108))
            c.blend(ellipse(x, y, int(rng.integers(1, 4)), int(rng.integers(1, 3))),
                    RAMPS[key][1], rng.random() * .4 + .15)
    return c.buf, parts


def render_frames(attrs, seed, nframes=8, scale=SCALE):
    plate, parts = render_plate(attrs, seed)
    out = []
    for f in range(nframes):
        c = Canvas()
        np.copyto(c.buf, plate)
        draw_frame(c, parts, attrs, 2 * np.pi * f / nframes,
                   np.random.default_rng(seed + f))
        out.append(c.to_image(scale))
    return out


def render_token(attrs, seed, frame=0, nframes=8, scale=SCALE):
    plate, parts = render_plate(attrs, seed)
    c = Canvas()
    np.copyto(c.buf, plate)
    draw_frame(c, parts, attrs, 2 * np.pi * frame / nframes,
               np.random.default_rng(seed))
    return c.to_image(scale)
