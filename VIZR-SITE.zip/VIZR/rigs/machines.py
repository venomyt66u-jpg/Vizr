"""The 20 machines. Each is a distinct silhouette — at collection scale the
outline is what separates one rig from another, so no two share a footprint.

Every builder returns a dict of masks the renderer needs for animation:
  'fans'   list of (cx, cy, r)   -> spun per frame
  'leds'   list of (x, y)        -> blink per frame
  'slot'   (x, y, w)             -> bills/coins eject from here
  'vents'  mask                  -> heat shimmer
  'screen' mask                  -> flicker
"""
import numpy as np
from .core import (NATIVE, blank, rect, ellipse, disc, line, shift, dilate,
                   erode, outline_of, panel, shade, ink, RAMPS)

FLOOR = 112


def _feet(c, x0, x1, y, key='rubber'):
    for fx in (x0 + 2, x1 - 6):
        panel(c, rect(fx, y, fx + 5, y + 4), key, (0, 1, 3, 5))


def _grill(c, m, key='carbon', step=3):
    ys = np.where(m.any(axis=1))[0]
    if not len(ys):
        return
    for y in range(ys[0] + 1, ys[-1], step):
        c.blend(rect(0, y, NATIVE, y + 1) & m, RAMPS[key][0], .55)
        c.blend(rect(0, y + 1, NATIVE, y + 2) & m, RAMPS[key][3], .25)


def _fan_well(c, cx, cy, r, key='carbon'):
    well = disc(cx, cy, r)
    shade(c, well, key, (1, 2, 5, 9))
    c.blend(disc(cx, cy, r - 1) & ~disc(cx, cy, r - 2), RAMPS[key][4], .4)
    ink(c, well)
    return (cx, cy, r - 2)


# ============================================================== MACHINES ====

def desktop_rig(c, k):
    body = rect(38, 44, 90, FLOOR)
    panel(c, body, k)
    face = rect(41, 47, 87, 108)
    panel(c, face, 'carbon', (1, 3, 7, 12))
    fans = [_fan_well(c, 52, 62, 11), _fan_well(c, 76, 62, 11)]
    scr = rect(45, 84, 83, 100)
    panel(c, scr, 'glass', (1, 2, 5, 9))
    _feet(c, 38, 90, FLOOR)
    ink(c, body)
    return dict(fans=fans, leds=[(45, 78), (49, 78), (53, 78)], screen=scr,
                vents=rect(41, 47, 87, 56), slot=None)


def tower_rig(c, k):
    body = rect(44, 22, 84, FLOOR)
    panel(c, body, k)
    face = rect(47, 25, 81, 108)
    panel(c, face, 'carbon', (1, 3, 7, 12))
    fans = [_fan_well(c, 64, 38, 12), _fan_well(c, 64, 66, 12)]
    _grill(c, rect(50, 84, 78, 104))
    _feet(c, 44, 84, FLOOR)
    ink(c, body)
    return dict(fans=fans, leds=[(52, 30), (76, 30)],
                screen=None, vents=rect(50, 84, 78, 104), slot=None)


def shelf_miner(c, k):
    fans = []
    for i, y in enumerate((40, 62, 84)):
        sh = rect(26, y, 102, y + 18)
        panel(c, sh, k)
        panel(c, rect(29, y + 3, 99, y + 15), 'carbon', (1, 3, 7, 12))
        fans.append(_fan_well(c, 38, y + 9, 7))
        fans.append(_fan_well(c, 90, y + 9, 7))
        _grill(c, rect(50, y + 4, 80, y + 14), step=2)
        ink(c, sh)
    for sx in (26, 98):
        panel(c, rect(sx, 36, sx + 4, FLOOR), 'steel', (0, 1, 3, 6))
    _feet(c, 24, 106, FLOOR)
    return dict(fans=fans, leds=[(32, 44), (32, 66), (32, 88)],
                screen=None, vents=rect(50, 40, 80, 100), slot=None)


def usb_miner(c, k):
    body = rect(54, 66, 74, 104)
    panel(c, body, k)
    plug = rect(58, 56, 70, 68)
    panel(c, plug, 'steel', (0, 1, 3, 6))
    fin = rect(56, 70, 72, 100)
    panel(c, fin, 'carbon', (1, 3, 7, 12))
    for y in range(72, 100, 3):
        c.blend(rect(56, y, 72, y + 1) & fin, RAMPS['carbon'][4], .35)
    _feet(c, 52, 78, 104)
    ink(c, body | plug)
    return dict(fans=[], leds=[(64, 102)], screen=None, vents=fin, slot=None)


def laptop_rig(c, k):
    base = rect(30, 92, 98, FLOOR)
    panel(c, base, k)
    lid = rect(34, 40, 94, 92)
    panel(c, lid, k)
    scr = rect(38, 44, 90, 86)
    panel(c, scr, 'glass', (2, 4, 9, 15))
    kb = rect(34, 96, 94, 106)
    panel(c, kb, 'carbon', (1, 2, 5, 9))
    for y in range(97, 106, 3):
        for x in range(36, 93, 4):
            c.blend(rect(x, y, x + 3, y + 2), RAMPS['carbon'][3], .5)
    ink(c, base | lid)
    return dict(fans=[], leds=[(34, 108)], screen=scr,
                vents=rect(30, 92, 98, 95), slot=None)


def open_frame(c, k):
    for sx in (22, 102):
        panel(c, rect(sx, 34, sx + 4, FLOOR), k, (0, 1, 3, 6))
    panel(c, rect(22, 34, 106, 38), k, (0, 1, 3, 6))
    panel(c, rect(22, FLOOR - 4, 106, FLOOR), k, (0, 1, 3, 6))
    fans = []
    for i, y in enumerate((44, 60, 76, 92)):
        card = rect(28, y, 100, y + 12)
        panel(c, card, 'carbon', (1, 3, 7, 12))
        panel(c, rect(30, y + 2, 98, y + 6), 'steel', (0, 1, 3, 6))
        fans.append(_fan_well(c, 42, y + 7, 5))
        fans.append(_fan_well(c, 62, y + 7, 5))
        fans.append(_fan_well(c, 82, y + 7, 5))
        ink(c, card)
    return dict(fans=fans, leds=[(96, 46), (96, 62), (96, 78), (96, 94)],
                screen=None, vents=None, slot=None)


def asic_box(c, k):
    body = rect(28, 48, 100, 104)
    panel(c, body, k)
    for sx, d in ((28, 1), (94, -1)):
        f = rect(sx, 48, sx + 6, 104)
        panel(c, f, 'steel', (0, 1, 3, 6))
    fans = [_fan_well(c, 46, 76, 15), _fan_well(c, 82, 76, 15)]
    panel(c, rect(38, 52, 90, 58), 'carbon', (0, 1, 3, 6))
    _feet(c, 28, 100, 104)
    ink(c, body)
    return dict(fans=fans, leds=[(34, 100), (38, 100)],
                screen=None, vents=rect(38, 52, 90, 58), slot=None)


def server_blade(c, k):
    body = rect(18, 52, 110, 96)
    panel(c, body, k)
    face = rect(21, 55, 107, 93)
    panel(c, face, 'carbon', (1, 3, 7, 12))
    for x in range(24, 104, 10):
        panel(c, rect(x, 58, x + 7, 90), 'steel', (0, 1, 3, 6))
        c.blend(rect(x + 1, 60, x + 6, 62), RAMPS['glass'][3], .8)
    for sx in (18, 106):
        panel(c, rect(sx, 50, sx + 4, 98), 'steel', (0, 1, 3, 6))
    ink(c, body)
    return dict(fans=[], leds=[(x + 3, 86) for x in range(24, 104, 10)],
                screen=None, vents=face, slot=None)


def cooling_tower(c, k):
    body = rect(46, 24, 82, FLOOR)
    panel(c, body, k)
    for y in range(30, 104, 8):
        panel(c, rect(43, y, 85, y + 5), 'steel', (0, 1, 3, 6))
    top = ellipse(64, 24, 20, 7)
    panel(c, top, 'steel', (1, 2, 5, 9))
    fans = [_fan_well(c, 64, 24, 13)]
    _feet(c, 44, 84, FLOOR)
    ink(c, body | top)
    return dict(fans=fans, leds=[(50, 100), (78, 100)], screen=None,
                vents=rect(46, 28, 82, 104), slot=None)


def bill_printer(c, k):
    body = rect(30, 56, 98, 104)
    panel(c, body, k)
    top = rect(34, 48, 94, 58)
    panel(c, top, k, (0, 1, 4, 8))
    slot = rect(38, 62, 90, 66)
    panel(c, slot, 'carbon', (0, 1, 3, 6))
    c.blend(rect(38, 62, 90, 63), RAMPS['carbon'][0])
    scr = rect(40, 72, 62, 84)
    panel(c, scr, 'glass', (1, 2, 5, 9))
    for x in range(68, 92, 6):
        panel(c, rect(x, 74, x + 4, 78), 'steel', (0, 1, 2, 4))
    _feet(c, 30, 98, 104)
    ink(c, body | top)
    return dict(fans=[], leds=[(66, 88), (72, 88), (78, 88)], screen=scr,
                vents=None, slot=(64, 62, 24))


def wall_cabinet(c, k):
    body = rect(26, 26, 102, 106)
    panel(c, body, k)
    door = rect(30, 30, 98, 102)
    panel(c, door, 'glass', (3, 6, 12, 20))
    fans = []
    for y in (36, 52, 68, 84):
        panel(c, rect(34, y, 94, y + 10), 'carbon', (1, 2, 5, 9))
        fans.append(_fan_well(c, 42, y + 5, 4))
        fans.append(_fan_well(c, 86, y + 5, 4))
    panel(c, rect(96, 60, 100, 72), 'steel', (0, 1, 2, 4))
    ink(c, body)
    return dict(fans=fans, leds=[(60, 40), (60, 56), (60, 72), (60, 88)],
                screen=None, vents=None, slot=None)


def immersion_tank(c, k):
    tank = rect(28, 46, 100, 106)
    panel(c, tank, 'glass', (3, 7, 14, 22))
    fluid = rect(31, 56, 97, 103)
    panel(c, fluid, 'teal', (3, 7, 14, 22))
    for i, x in enumerate(range(36, 94, 14)):
        panel(c, rect(x, 62, x + 9, 98), 'carbon', (1, 2, 5, 9))
        for y in range(64, 96, 4):
            c.blend(rect(x + 1, y, x + 8, y + 1), RAMPS['steel'][3], .6)
    frame = outline_of(tank, 2)
    panel(c, frame, k, (0, 1, 3, 6))
    panel(c, rect(28, 42, 100, 50), k, (0, 1, 4, 8))
    ink(c, tank)
    return dict(fans=[], leds=[(34, 100), (94, 100)], screen=None,
                vents=None, slot=None, bubbles=fluid)


def solar_rig(c, k):
    pan = rect(20, 30, 108, 62)
    panel(c, pan, 'navy', (2, 5, 10, 16))
    for x in range(24, 106, 11):
        c.blend(rect(x, 30, x + 1, 62) & pan, RAMPS['navy'][4], .5)
    for y in range(36, 62, 9):
        c.blend(rect(20, y, 108, y + 1) & pan, RAMPS['navy'][4], .4)
    ink(c, pan)
    panel(c, rect(60, 62, 68, 84), 'steel', (0, 1, 3, 6))
    box = rect(42, 84, 86, 106)
    panel(c, box, k)
    fans = [_fan_well(c, 74, 95, 7)]
    scr = rect(48, 90, 66, 100)
    panel(c, scr, 'glass', (1, 2, 5, 9))
    _feet(c, 42, 86, 106)
    ink(c, box)
    return dict(fans=fans, leds=[(70, 104)], screen=scr, vents=None, slot=None)


def coin_press(c, k):
    base = rect(26, 84, 102, 106)
    panel(c, base, k)
    col = rect(52, 34, 76, 86)
    panel(c, col, 'steel', (1, 3, 7, 12))
    head = rect(42, 26, 86, 42)
    panel(c, head, k, (0, 1, 4, 8))
    ram = rect(56, 42, 72, 68)
    panel(c, ram, 'brass', (1, 2, 5, 9))
    anvil = rect(48, 76, 80, 86)
    panel(c, anvil, 'gunmetal', (1, 2, 5, 9))
    for sx in (30, 94):
        panel(c, rect(sx, 40, sx + 5, 86), 'steel', (0, 1, 3, 6))
    _feet(c, 26, 102, 106)
    ink(c, base | head | col)
    return dict(fans=[], leds=[(34, 90), (94, 90)], screen=None, vents=None,
                slot=(64, 78, 16), ram=ram)


def vault_printer(c, k):
    body = rect(24, 34, 104, 106)
    panel(c, body, k)
    door = disc(64, 68, 28)
    panel(c, door, 'steel', (2, 5, 10, 17))
    c.blend(disc(64, 68, 26) & ~disc(64, 68, 24), RAMPS['steel'][4], .5)
    wheel = (disc(64, 68, 12) & ~disc(64, 68, 8))
    panel(c, wheel, 'brass', (0, 1, 3, 6))
    for a in range(4):
        ang = a * np.pi / 4
        c.blend(line(64 + np.cos(ang) * 6, 68 + np.sin(ang) * 6,
                     64 - np.cos(ang) * 6, 68 - np.sin(ang) * 6, 2)
                & disc(64, 68, 13), RAMPS['brass'][3])
    ink(c, door)
    slot = rect(44, 98, 84, 102)
    panel(c, slot, 'carbon', (0, 1, 3, 6))
    _feet(c, 24, 104, 106)
    ink(c, body)
    return dict(fans=[], leds=[(30, 40), (98, 40)], screen=None, vents=None,
                slot=(64, 98, 20), wheel=(64, 68, 12))


def data_furnace(c, k):
    body = rect(30, 30, 98, 106)
    panel(c, body, k)
    mouth = rect(40, 66, 88, 96)
    panel(c, mouth, 'carbon', (2, 4, 9, 15))
    grate = blank()
    for x in range(42, 88, 5):
        grate |= rect(x, 66, x + 3, 96)
    panel(c, grate, 'gunmetal', (0, 1, 3, 6))
    stack = rect(38, 12, 52, 32)
    panel(c, stack, 'rust', (1, 2, 5, 9))
    panel(c, rect(35, 8, 55, 14), 'rust', (0, 1, 3, 6))
    for y in range(38, 62, 7):
        panel(c, rect(36, y, 92, y + 4), 'steel', (0, 1, 3, 6))
    _feet(c, 30, 98, 106)
    ink(c, body | stack)
    return dict(fans=[], leds=[(90, 40), (90, 48)], screen=None,
                vents=mouth, slot=None, fire=mouth, smoke=(45, 8))


def quantum_cab(c, k):
    body = rect(34, 20, 94, 106)
    panel(c, body, k)
    win = rect(38, 26, 90, 88)
    panel(c, win, 'glass', (3, 7, 14, 22))
    for i, y in enumerate(range(32, 84, 10)):
        r = 22 - i * 3
        ringm = (ellipse(64, y + 4, r, 4) & ~ellipse(64, y + 4, r - 3, 2))
        panel(c, ringm & win, 'brass', (0, 1, 3, 6))
    core = disc(64, 78, 6)
    panel(c, core, 'glass', (0, 1, 2, 4))
    panel(c, rect(38, 92, 90, 102), 'carbon', (1, 2, 5, 9))
    _feet(c, 34, 94, 106)
    ink(c, body)
    return dict(fans=[], leds=[(44, 97), (52, 97), (60, 97), (68, 97)],
                screen=None, vents=None, slot=None, core=core)


def steam_rig(c, k):
    boiler = ellipse(58, 70, 26, 24)
    panel(c, boiler, k)
    for y in range(52, 92, 8):
        c.blend(rect(0, y, NATIVE, y + 2) & boiler, RAMPS['brass'][2], .8)
    stack = rect(46, 24, 60, 50)
    panel(c, stack, 'brass', (1, 2, 5, 9))
    panel(c, rect(43, 20, 63, 26), 'brass', (0, 1, 3, 6))
    fw = disc(94, 76, 16) & ~disc(94, 76, 11)
    panel(c, fw, 'brass', (0, 1, 3, 6))
    for a in range(6):
        ang = a * np.pi / 3
        c.blend(line(94 + np.cos(ang) * 5, 76 + np.sin(ang) * 5,
                     94 + np.cos(ang) * 15, 76 + np.sin(ang) * 15, 2)
                & disc(94, 76, 16), RAMPS['brass'][2])
    gauge = disc(40, 60, 7)
    panel(c, gauge, 'ivory', (0, 1, 3, 5))
    ink(c, gauge)
    panel(c, rect(30, 96, 104, 106), 'wood', (1, 3, 7, 12))
    ink(c, boiler | stack)
    return dict(fans=[], leds=[(70, 100)], screen=None, vents=None,
                slot=None, smoke=(53, 20), wheel=(94, 76, 15), gauge=(40, 60, 5))


def gold_foundry(c, k):
    base = rect(20, 88, 108, 106)
    panel(c, base, 'concrete', (2, 4, 9, 15))
    vat = rect(34, 40, 94, 88)
    panel(c, vat, 'gunmetal', (2, 5, 10, 17))
    melt = rect(38, 46, 90, 56)
    panel(c, melt, 'gold', (0, 1, 2, 4))
    spout = rect(88, 62, 104, 70)
    panel(c, spout, 'gunmetal', (0, 1, 3, 6))
    mould = rect(96, 78, 116, 90)
    panel(c, mould, 'steel', (1, 2, 5, 9))
    for x in range(38, 90, 9):
        panel(c, rect(x, 62, x + 6, 86), 'gold', (1, 2, 5, 9))
    hood = rect(30, 28, 98, 40)
    panel(c, hood, 'rust', (1, 3, 7, 12))
    ink(c, vat | hood | base)
    return dict(fans=[], leds=[(26, 94), (102, 94)], screen=None,
                vents=None, slot=(104, 70, 8), fire=melt, smoke=(64, 28))


def the_mint(c, k):
    base = rect(14, 92, 114, 108)
    panel(c, base, 'concrete', (2, 4, 9, 15))
    body = rect(22, 30, 106, 92)
    panel(c, body, 'gold', (3, 7, 14, 22))
    face = rect(26, 34, 102, 88)
    panel(c, face, 'gunmetal', (2, 5, 10, 17))
    fans = [_fan_well(c, 40, 50, 9), _fan_well(c, 88, 50, 9)]
    scr = rect(52, 40, 76, 60)
    panel(c, scr, 'glass', (1, 2, 5, 9))
    for i, y in enumerate((68, 76)):
        panel(c, rect(30, y, 98, y + 5), 'carbon', (0, 1, 3, 6))
    slot = rect(46, 84, 82, 88)
    panel(c, slot, 'carbon', (0, 1, 3, 6))
    for sx in (22, 102):
        panel(c, rect(sx, 24, sx + 4, 92), 'brass', (0, 1, 3, 6))
    panel(c, rect(18, 22, 110, 30), 'brass', (0, 1, 4, 8))
    ink(c, body | base)
    return dict(fans=fans, leds=[(34, 84), (40, 84), (94, 84), (88, 84)],
                screen=scr, vents=None, slot=(64, 84, 18))


MACHINES = {
    'Desktop Rig': desktop_rig, 'Tower Rig': tower_rig,
    'Shelf Miner': shelf_miner, 'USB Miner': usb_miner,
    'Laptop Rig': laptop_rig, 'Open Frame': open_frame,
    'ASIC Box': asic_box, 'Server Blade': server_blade,
    'Cooling Tower': cooling_tower, 'Bill Printer': bill_printer,
    'Wall Cabinet': wall_cabinet, 'Immersion Tank': immersion_tank,
    'Solar Rig': solar_rig, 'Coin Press': coin_press,
    'Vault Printer': vault_printer, 'Data Furnace': data_furnace,
    'Quantum Cabinet': quantum_cab, 'Steam Rig': steam_rig,
    'Gold Foundry': gold_foundry, 'The Mint': the_mint,
}
