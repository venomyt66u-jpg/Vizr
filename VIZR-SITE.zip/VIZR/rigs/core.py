"""RIG ENGINE — pixel machines, built for speed.

The clay renderer is ~30s a token; 3333 animated tokens would be days. This is
the same compositing architecture that got the earlier pixel collection to
sub-second: boolean masks on a native grid, one global light vector, managed
colour ramps, integer upscale, and — the big one — a STATIC PLATE rendered once
per token and copied for every frame, with only the moving layers repainted.
"""
import numpy as np

NATIVE = 128
SCALE = 6                 # 128 * 6 = 768
LIGHT = (-1, -1)


def ramp(*hexes):
    out = []
    for h in hexes:
        h = h.lstrip('#')
        out.append((int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255))
    return out


RAMPS = {
    # chassis metals / plastics
    'steel':   ramp('22242c', '3d414d', '626875', '8d94a2', 'bcc3d0'),
    'gunmetal':ramp('191b21', '2c2f38', '474c58', '676d7c', '8f96a6'),
    'ivory':   ramp('5c584e', '8b8578', 'b8b1a1', 'd9d3c4', 'f2eee4'),
    'copper':  ramp('4a2415', '7d4224', 'b06a38', 'd29255', 'ecbc86'),
    'gold':    ramp('4d3410', '8a6318', 'c9971f', 'edc351', 'fceb9d'),
    'crimson': ramp('3d0f16', '6b1c25', '9c2d35', 'c4514f', 'e0806f'),
    'teal':    ramp('0d2b2c', '164747', '256867', '3d8a86', '63aca6'),
    'navy':    ramp('101a30', '1e2f4d', '32496e', '4d6890', '7189b0'),
    'olive':   ramp('2b3018', '4a5228', '6e7a3c', '94a256', 'bcc87e'),
    'plum':    ramp('26122c', '412048', '5f3466', '804d85', 'a271a4'),
    'rust':    ramp('44200f', '73391a', 'a3562a', 'c67c44', 'e2a468'),
    'mint':    ramp('11332b', '1d5548', '2e7f6b', '46a68d', '6fc9b0'),
    'carbon':  ramp('101014', '1c1c22', '2c2c34', '414149', '5c5c66'),
    'brass':   ramp('4a3a12', '7d631f', 'ad8c2e', 'd0b055', 'ecd489'),
    # accents
    'glass':   ramp('0a1a22', '11303c', '1a4d5e', '2a7286', '46a0b4'),
    'rubber':  ramp('141418', '212127', '303039', '3f3f4a', '52525e'),
    'wood':    ramp('2c1d13', '4a3222', '6d4c33', '8f6a49', 'b08b64'),
    'paper':   ramp('8a8574', 'b5b0a0', 'd8d4c6', 'ecead f'.replace(' ', ''), 'faf8f2'),
    'concrete':ramp('2e2e33', '46464d', '626269', '82828a', 'a5a5ad'),
}

LED = {
    'Green':  (96, 246, 138), 'Amber': (252, 186, 62), 'Red': (250, 82, 78),
    'Cyan':   (86, 226, 250), 'Violet': (186, 122, 250), 'White': (238, 246, 252),
    'Lime':   (196, 250, 74), 'Pink': (250, 128, 196),
}

BG = {
    'Server Grey': ('concrete', 0), 'Deep Navy': ('navy', 0), 'Vault': ('carbon', 0),
    'Rust Room': ('rust', 0), 'Teal Lab': ('teal', 0), 'Olive Bunker': ('olive', 0),
    'Plum Den': ('plum', 0), 'Gold Vault': ('gold', 0), 'Crimson Bay': ('crimson', 0),
    'Cold Steel': ('steel', 0),
}


def blank(w=NATIVE, h=NATIVE):
    return np.zeros((h, w), dtype=bool)


def shift(m, dx, dy):
    out = np.zeros_like(m)
    h, w = m.shape
    xs0, xs1 = max(0, dx), min(w, w + dx)
    ys0, ys1 = max(0, dy), min(h, h + dy)
    if xs0 >= xs1 or ys0 >= ys1:
        return out
    out[ys0:ys1, xs0:xs1] = m[ys0 - dy:ys1 - dy, xs0 - dx:xs1 - dx]
    return out


def dilate(m, r=1):
    out = m.copy()
    for _ in range(r):
        acc = out.copy()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            acc |= shift(out, dx, dy)
        out = acc
    return out


def erode(m, r=1):
    return ~dilate(~m, r)


def outline_of(m, t=1):
    return dilate(m, t) & ~m


def rect(x0, y0, x1, y1, w=NATIVE, h=NATIVE):
    m = blank(w, h)
    x0, y0 = max(0, int(x0)), max(0, int(y0))
    x1, y1 = int(x1), int(y1)
    m[y0:max(y0, y1), x0:max(x0, x1)] = True
    return m


_GRID = {}


def ellipse(cx, cy, rx, ry, w=NATIVE, h=NATIVE):
    rx, ry = max(rx, .5), max(ry, .5)
    m = np.zeros((h, w), dtype=bool)
    x0, x1 = max(0, int(cx - rx) - 1), min(w, int(cx + rx) + 2)
    y0, y1 = max(0, int(cy - ry) - 1), min(h, int(cy + ry) + 2)
    if x0 >= x1 or y0 >= y1:
        return m
    yy, xx = np.mgrid[y0:y1, x0:x1]
    m[y0:y1, x0:x1] = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2 <= 1.0
    return m


def disc(cx, cy, r, w=NATIVE, h=NATIVE):
    return ellipse(cx, cy, r, r, w, h)


def line(x0, y0, x1, y1, t=1, w=NATIVE, h=NATIVE):
    m = blank(w, h)
    x0, y0, x1, y1 = int(x0), int(y0), int(x1), int(y1)
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx + dy
    x, y = x0, y0
    while True:
        if 0 <= x < w and 0 <= y < h:
            m[y, x] = True
        if x == x1 and y == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy; x += sx
        if e2 <= dx:
            err += dx; y += sy
    if t > 1:
        m = dilate(m, t - 1)
    return m


_BAYER = {}


def bayer(shape, level=4):
    key = (shape, level)
    if key in _BAYER:
        return _BAYER[key]
    b = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]])
    h, w = shape
    t = np.tile(b, (h // 4 + 1, w // 4 + 1))[:h, :w]
    out = t < level
    out.flags.writeable = False
    _BAYER[key] = out
    return out


class Canvas:
    def __init__(self, w=NATIVE, h=NATIVE):
        self.w, self.h = w, h
        self.buf = np.zeros((h, w, 4), dtype=np.float32)

    def blend(self, mask, color, alpha=1.0):
        if mask is None or not mask.any():
            return
        c = np.array(color[:3], dtype=np.float32)
        a = (color[3] / 255.0 if len(color) > 3 else 1.0) * alpha
        dst = self.buf[mask]
        out_a = a + dst[:, 3] / 255.0 * (1 - a)
        rgb = c * a + dst[:, :3] * (dst[:, 3:4] / 255.0) * (1 - a)
        rgb = np.where(out_a[:, None] > 0, rgb / np.maximum(out_a[:, None], 1e-6), 0)
        self.buf[mask] = np.concatenate([rgb, (out_a * 255)[:, None]], axis=1)

    def add(self, mask, color, strength=1.0):
        if not mask.any():
            return
        c = np.array(color[:3], dtype=np.float32) * strength
        cur = self.buf[mask]
        cur[:, :3] = np.minimum(cur[:, :3] + c, 255)
        cur[:, 3] = np.maximum(cur[:, 3], 255)
        self.buf[mask] = cur

    def multiply(self, mask, f):
        if not mask.any():
            return
        cur = self.buf[mask]
        cur[:, :3] = cur[:, :3] * f
        self.buf[mask] = cur

    def to_image(self, scale=SCALE):
        from PIL import Image
        arr = np.clip(self.buf, 0, 255).astype(np.uint8)
        return Image.fromarray(arr, 'RGBA').resize(
            (self.w * scale, self.h * scale), Image.NEAREST)


def light_depth(mask, ld=LIGHT, max_steps=30):
    depth = np.zeros(mask.shape, dtype=np.int16)
    acc = mask.copy()
    for k in range(1, max_steps + 1):
        acc = acc & shift(mask, -ld[0] * k, -ld[1] * k)
        if not acc.any():
            break
        depth[acc] = k
    depth[~mask] = -1
    return depth


def shade(c, mask, key, bands=(1, 3, 7, 11), alpha=1.0):
    """Ramped directional shading. Bands are painted solid then boundaries are
    dithered by OVERPAINTING — removing pixels instead would expose whatever
    is underneath, which reads as dirt rather than gradient."""
    if not mask.any():
        return
    pal = RAMPS[key] if isinstance(key, str) else key
    d = light_depth(mask)
    b0, b1, b2, b3 = bands
    sel = [((d >= 0) & (d <= b0), 4), ((d > b0) & (d <= b1), 3),
           ((d > b1) & (d <= b2), 2), ((d > b2) & (d <= b3), 1), ((d > b3), 0)]
    for region, idx in sel:
        c.blend(region & mask, pal[idx], alpha)
    area = int(mask.sum())
    rows = np.count_nonzero(mask.any(axis=1))
    cols = np.count_nonzero(mask.any(axis=0))
    if area >= 200 and min(rows, cols) >= 8:
        dith = bayer(mask.shape, 6)
        for bi, thr in enumerate((b0, b1, b2, b3)):
            edge = mask & (d == thr) & dith
            if edge.any():
                c.blend(edge, pal[sel[bi + 1][1]], alpha)


def ink(c, mask, col=(14, 12, 18, 255), a=1.0):
    c.blend(outline_of(mask), col, a)


def panel(c, m, key, bands=(1, 3, 7, 12), edge=True):
    """A shaded plate with a lit top-left lip and an occluded bottom-right —
    the single move that makes flat rectangles read as machined metal."""
    shade(c, m, key, bands)
    pal = RAMPS[key]
    if edge:
        c.blend(m & ~shift(m, 0, 1), pal[4], .55)
        c.blend(m & ~shift(m, 1, 0), pal[4], .35)
        c.blend(m & ~shift(m, 0, -1), pal[0], .75)
        c.blend(m & ~shift(m, -1, 0), pal[0], .55)


def glow(c, m, col, radius=5, strength=.85):
    prev = m.copy()
    for r in range(1, radius + 1):
        ring = dilate(m, r) & ~prev
        c.add(ring, tuple(int(v * .45) for v in col),
              strength * (1 - r / (radius + 1.0)) ** 2.0)
        prev = dilate(m, r)
