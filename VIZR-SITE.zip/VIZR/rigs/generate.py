"""RIGS — 3333 collection generator.

Machines are split into rarity tiers rather than weighted individually, so the
tier is a legible thing a holder can talk about instead of an arbitrary number.
"""
import os, csv, argparse, hashlib
import numpy as np
from PIL import Image

from .render import render_frames, render_token
from .core import BG, LED, RAMPS

SUPPLY = 3333
LAYERS = ['Machine', 'Tier', 'Chassis', 'LED', 'Output', 'Cables',
          'Wear', 'Background']

# Tier -> (share of supply, machines in that tier)
TIERS = {
    'Common':    (0.42, ['Desktop Rig', 'Tower Rig', 'USB Miner',
                         'Laptop Rig', 'Shelf Miner', 'Open Frame']),
    'Uncommon':  (0.28, ['ASIC Box', 'Server Blade', 'Cooling Tower',
                         'Wall Cabinet', 'Bill Printer']),
    'Rare':      (0.19, ['Immersion Tank', 'Solar Rig', 'Coin Press',
                         'Vault Printer']),
    'Epic':      (0.09, ['Data Furnace', 'Quantum Cabinet', 'Steam Rig']),
    'Legendary': (0.02, ['Gold Foundry', 'The Mint']),
}

POOLS = {
    'Chassis': [(150, 'steel'), (135, 'gunmetal'), (120, 'carbon'),
                (105, 'navy'), (95, 'olive'), (85, 'teal'), (75, 'crimson'),
                (65, 'rust'), (55, 'ivory'), (45, 'plum'), (34, 'copper'),
                (22, 'brass')],
    'LED': [(170, 'Green'), (145, 'Amber'), (125, 'Cyan'), (105, 'Red'),
            (85, 'White'), (68, 'Lime'), (52, 'Violet'), (34, 'Pink')],
    'Output': [(230, 'None'), (150, 'Bills'), (105, 'Coins'), (60, 'Cards')],
    'Cables': [(170, 'Few'), (130, 'Messy'), (90, 'None')],
    'Wear': [(180, 'Clean'), (140, 'Scuffed'), (85, 'Rusted')],
    'Background': [(140, 'Server Grey'), (125, 'Deep Navy'), (110, 'Vault'),
                   (100, 'Cold Steel'), (90, 'Teal Lab'), (80, 'Olive Bunker'),
                   (70, 'Rust Room'), (60, 'Plum Den'), (48, 'Crimson Bay'),
                   (30, 'Gold Vault')],
}

# Machines with no eject slot can't print anything
NO_SLOT = {'Desktop Rig', 'Tower Rig', 'Shelf Miner', 'USB Miner', 'Laptop Rig',
           'Open Frame', 'ASIC Box', 'Server Blade', 'Cooling Tower',
           'Wall Cabinet', 'Immersion Tank', 'Solar Rig', 'Data Furnace',
           'Quantum Cabinet', 'Steam Rig'}


def pick(rng, layer):
    ws = np.array([w for w, _ in POOLS[layer]], dtype=float)
    ws /= ws.sum()
    return POOLS[layer][rng.choice(len(ws), p=ws)][1]


def coherent(a):
    if a['Machine'] in NO_SLOT and a['Output'] != 'None':
        return False                       # nothing to eject from
    if a['Machine'] in ('Gold Foundry', 'The Mint', 'Coin Press',
                        'Vault Printer', 'Bill Printer') and a['Output'] == 'None':
        return False                       # a printer that prints nothing
    if a['Machine'] == 'Gold Foundry' and a['Output'] != 'Coins':
        return False
    if a['Machine'] == 'Coin Press' and a['Output'] != 'Coins':
        return False
    if a['Machine'] == 'The Mint' and a['Wear'] == 'Rusted':
        return False
    if a['Machine'] == 'USB Miner' and a['Cables'] == 'Messy':
        return False                       # one stick, five cables
    if a['Chassis'] == 'carbon' and a['Background'] == 'Vault':
        return False                       # black on black
    return True


def build_set(supply=SUPPLY, seed=20260901):
    rng = np.random.default_rng(seed)
    tokens, seen = [], set()

    quota = {t: int(round(supply * share)) for t, (share, _) in TIERS.items()}
    quota['Common'] += supply - sum(quota.values())

    order = ['Legendary', 'Epic', 'Rare', 'Uncommon', 'Common']
    for tier in order:
        _, machines = TIERS[tier]
        made, guard = 0, 0
        while made < quota[tier] and guard < quota[tier] * 500 + 5000:
            guard += 1
            a = {'Machine': machines[int(rng.integers(0, len(machines)))],
                 'Tier': tier}
            for l in POOLS:
                a[l] = pick(rng, l)
            if not coherent(a):
                continue
            key = tuple(a[l] for l in LAYERS)
            if key in seen:
                continue
            seen.add(key)
            tokens.append(a)
            made += 1

    rng.shuffle(tokens)
    # the two Legendary machines lead the collection
    tokens.sort(key=lambda a: 0 if a['Tier'] == 'Legendary' else 1)
    return tokens


def token_seed(i):
    return int(hashlib.sha256(f'rig-{i}'.encode()).hexdigest()[:12], 16) % (2 ** 31)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='rigs_out')
    ap.add_argument('--supply', type=int, default=SUPPLY)
    ap.add_argument('--frames', type=int, default=8)
    ap.add_argument('--scale', type=int, default=6)
    ap.add_argument('--static', action='store_true')
    ap.add_argument('--limit', type=int, default=0)
    args = ap.parse_args()

    imgdir = os.path.join(args.out, 'images')
    os.makedirs(imgdir, exist_ok=True)
    tokens = build_set(args.supply)
    ext = 'png' if args.static else 'gif'

    rows = []
    for i, a in enumerate(tokens, 1):
        nm = f"{a['Machine']} #{i}"
        rows.append({'tokenID': i, 'name': nm, 'file_name': f'{i}.{ext}',
                     **{f'attributes[{k}]': a[k] for k in LAYERS}})
    with open(os.path.join(args.out, 'metadata.csv'), 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    n = args.limit or len(tokens)
    for i, a in enumerate(tokens[:n], 1):
        sd = token_seed(i)
        if args.static:
            render_token(a, sd, 0, args.frames, args.scale).convert('RGB').save(
                os.path.join(imgdir, f'{i}.png'))
        else:
            fr = [im.convert('RGB') for im in
                  render_frames(a, sd, args.frames, args.scale)]
            pal = fr[0].quantize(colors=128, method=Image.MEDIANCUT)
            qs = [x.quantize(palette=pal, dither=Image.NONE) for x in fr]
            qs[0].save(os.path.join(imgdir, f'{i}.gif'), save_all=True,
                       append_images=qs[1:], duration=110, loop=0,
                       optimize=True, disposal=2)
        if i % 250 == 0:
            print(f'  {i}/{n}', flush=True)
    print('done', n)


if __name__ == '__main__':
    main()
